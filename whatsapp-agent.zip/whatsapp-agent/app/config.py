from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Base de datos
    database_url: str

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # OpenAI
    openai_api_key: str

    # WhatsApp
    whatsapp_token: str
    whatsapp_phone_id: str
    whatsapp_verify_token: str

    # Pagos
    stripe_secret_key: str
    base_url: str = "http://localhost:8000"

    class Config:
        env_file = ".env"


settings = Settings()

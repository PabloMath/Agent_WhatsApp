"""
Tareas Celery para procesar mensajes de WhatsApp de forma asíncrona.
Esto evita que el webhook de Meta espere más de 5 segundos y reintente.
"""

import asyncio
import httpx
from celery import Celery

from app.config import settings

celery_app = Celery(
    "whatsapp_agent",
    broker=settings.redis_url,
    backend=settings.redis_url,
)

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="America/Bogota",
    task_track_started=True,
)


def _send_whatsapp_message(phone: str, text: str) -> None:
    """Envía un mensaje de texto a un número de WhatsApp via Meta Cloud API."""
    url = f"https://graph.facebook.com/v19.0/{settings.whatsapp_phone_id}/messages"
    headers = {
        "Authorization": f"Bearer {settings.whatsapp_token}",
        "Content-Type": "application/json",
    }
    payload = {
        "messaging_product": "whatsapp",
        "to": phone,
        "type": "text",
        "text": {"body": text},
    }
    with httpx.Client() as client:
        response = client.post(url, json=payload, headers=headers)
        response.raise_for_status()


@celery_app.task(bind=True, max_retries=3, default_retry_delay=5)
def process_whatsapp_message(self, phone: str, message: str) -> None:
    """
    Tarea principal: procesa el mensaje con el agente y responde al usuario.
    Se reintenta hasta 3 veces en caso de error.
    """
    try:
        from app.agent.agent import handle_message

        # handle_message es async — lo corremos en un event loop
        respuesta = asyncio.run(handle_message(phone, message))
        _send_whatsapp_message(phone, respuesta)

    except Exception as exc:
        raise self.retry(exc=exc)

"""
Memoria de conversación persistida en Redis.
Cada número de WhatsApp tiene su propio historial independiente.
"""

from langchain.memory import ConversationBufferWindowMemory
from langchain_community.chat_message_histories import RedisChatMessageHistory

from app.config import settings


def get_memory(phone: str, k: int = 10) -> ConversationBufferWindowMemory:
    """
    Retorna una memoria de ventana deslizante con historial en Redis.

    - k=10: recuerda los últimos 10 turnos de conversación.
    - TTL de 24 horas por sesión (se renueva con cada mensaje).
    - Si Redis cae, LangChain lanza excepción — considera fallback a in-memory.
    """
    history = RedisChatMessageHistory(
        session_id=f"whatsapp:{phone}",
        url=settings.redis_url,
        ttl=86400,  # 24 horas en segundos
    )

    return ConversationBufferWindowMemory(
        k=k,
        chat_memory=history,
        memory_key="chat_history",
        return_messages=True,
    )


def clear_memory(phone: str) -> None:
    """Borra el historial de conversación de un usuario (útil para pruebas)."""
    from langchain_community.chat_message_histories import RedisChatMessageHistory
    history = RedisChatMessageHistory(
        session_id=f"whatsapp:{phone}",
        url=settings.redis_url,
    )
    history.clear()
